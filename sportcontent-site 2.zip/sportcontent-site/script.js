// Simple interactivity for demo
document.addEventListener('DOMContentLoaded', function(){
  console.log('SPORTKONTENT demo loaded');
});